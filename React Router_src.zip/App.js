import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './Website/Pages/Home'
import Dashboard from './Admin/Dashboard'
import Lazyloading from './Admin/Lazyloading'
import Loading from './Admin/Categories'
import SearchFilter from './Search/SearchFilter'

function App() {
  return (
    <div>
      <BrowserRouter>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/dashboard' element={<Dashboard/>}/>
        <Route path='/categories' element={<Loading/>}/>
        <Route path='/lazy' element={<Lazyloading/>}/>
      </Routes>
      </BrowserRouter>
      {/* <SearchFilter></SearchFilter> */}
    </div>
  )
}

export default App