import React from 'react'
import Header from './Header'
import Link_navbar from './Link_navbar'
import Section from './Section'
import Sliders from './Sliders'
import Cards from './Cards'

function Template() {
  return (
    <div>
     <Header/>
     <Link_navbar/>
     <Section/>
     <Sliders/>
     <Cards/>
    </div>
  )
}

export default Template