import React from 'react'
import Template from './Template_task/Template'
import State_task from './Task/State_task'
import List_task from './Task/List_task'
import One from './Task/One'

function App() {
  return (
    <div>
    <Template/>
    {/* <State_task/> */}
    {/* <List_task/> */}
    {/* <One/> */}
    </div>
  )
}

export default App